#include "animationFrame.h"

animationFrame::animationFrame()
{
	//setting variable when created
	animationNumb = 0;
}

animationFrame::~animationFrame()
{}

void animationFrame::init(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Sprite* sprite_, gef::Vector2 spritePos)
{
	//setting variable to the return value of function
	frame_variables.text_atlas = ReadTextureAtlasFromJSON(tex_document);
	
	//looping through the file to get armature data
	const rapidjson::Value& armature_array = ske_document["armature"];
	for (int armature_num = 0; armature_num < (int)armature_array.Size(); ++armature_num)
	{
		frame_variables.armature.push_back(ReadArmaturefromJSON(armature_array[armature_num]));
	}

	//function to set sprite variables
	SetSpriteSizeandPositionFrame(sprite_, spritePos.x, spritePos.y, frame_variables.text_atlas, frame_variables.armature.at(animationNumb)->frame_order.at(frame_variables.frame));
}

void animationFrame::update(float frame_time, int animNumb)
{
	//updating variables
	animationNumb = animNumb;
	frame_variables.animation_timer += frame_time;

	//checking and setting the timer based on the animation
	if (frame_variables.animation_timer >= (1.f / frame_variables.armature.at(animationNumb)->frameRate))
	{
		frame_variables.frame++;
		frame_variables.animation_timer = 0;
	}

	//checking and setting the frame
	if (frame_variables.frame >= frame_variables.armature.at(animationNumb)->duration)
	{
		frame_variables.frame = 0;
	}

}

void animationFrame::render(gef::SpriteRenderer * sprite_renderer, gef::Sprite sprite_, gef::Vector2 spritePos)
{
	//function to set sprite variables and then renders sprite
	SetSpriteSizeandPositionFrame(&sprite_, spritePos.x, spritePos.y, frame_variables.text_atlas, frame_variables.armature.at(animationNumb)->frame_order.at(frame_variables.frame));
	sprite_renderer->DrawSprite(sprite_);
}

textureAtlas* animationFrame::ReadTextureAtlasFromJSON(rapidjson::Document& tex_document)
{
	//creating a new atlas and setting variables
	textureAtlas* texture_atlas = new textureAtlas();
	texture_atlas->name = tex_document["name"].GetString();
	texture_atlas->width = tex_document["width"].GetFloat();
	texture_atlas->height = tex_document["height"].GetFloat();

	//looping through length of the subtextures
	const rapidjson::Value& subtexture_array = tex_document["SubTexture"];
	for (int subtex_num = 0; subtex_num < (int)subtexture_array.Size(); ++subtex_num)
	{
		//reading through subtexture values 
		subTexture* subtexture = ReadSubTextureFromJSON(subtexture_array[subtex_num]);
		texture_atlas->subTextures.push_back(*subtexture);
		delete subtexture;
	}

	//return the atlas
	return texture_atlas;
}

subTexture* animationFrame::ReadSubTextureFromJSON(const rapidjson::Value& subtexture_array)
{
	//creating a new subtexture class and assigning values
	subTexture* sub_texture = new subTexture();
	sub_texture->subName = subtexture_array["name"].GetString();
	sub_texture->subWidth = subtexture_array["width"].GetFloat();
	sub_texture->subHeight = subtexture_array["height"].GetFloat();
	sub_texture->subX = subtexture_array["x"].GetFloat();
	sub_texture->subY = subtexture_array["y"].GetFloat();
	sub_texture->subFrameX = subtexture_array["frameX"].GetFloat();
	sub_texture->subFrameY = subtexture_array["frameY"].GetFloat();
	sub_texture->subFrameWidth = subtexture_array["frameWidth"].GetFloat();
	sub_texture->subFrameHeight = subtexture_array["frameHeight"].GetFloat();

	//returning the subtexture
	return sub_texture;
}

void animationFrame::SetSpriteSizeandPositionFrame(gef::Sprite* sprite, float screen_x, float screen_y, textureAtlas* texture_atlas, std::string frame_order_name)
{
	//for loop for the size of the subtexure vector
	for (int frame = 0; frame < texture_atlas->subTextures.size(); frame++)
	{
		//checking to see if names are the same
		if (frame_order_name == texture_atlas->subTextures.at(frame).subName)
		{
			//assigns value at the specific vector
			float width = texture_atlas->subTextures.at(frame).subWidth;
			float height = texture_atlas->subTextures.at(frame).subHeight;
			float x = texture_atlas->subTextures.at(frame).subX;
			float y = texture_atlas->subTextures.at(frame).subY;
			float frame_width = texture_atlas->subTextures.at(frame).subFrameWidth;
			float frame_height = texture_atlas->subTextures.at(frame).subFrameHeight;
			float frameX = texture_atlas->subTextures.at(frame).subFrameX;
			float frameY = texture_atlas->subTextures.at(frame).subFrameY;

			//setting sprite variables
			sprite->set_width(width);
			sprite->set_height(height);
			sprite->set_uv_width(width / texture_atlas->width);
			sprite->set_uv_height(height / texture_atlas->height);

			float u = x / texture_atlas->width;
			float v = y / texture_atlas->height;
			sprite->set_uv_position(gef::Vector2(u, v));

			float sprite_x = width * 0.5 - (frame_width * 0.5f + frameX);
			float sprite_y = height * 0.5 - (frame_height * 0.5f + frameY);

			sprite->set_position(gef::Vector4(screen_x + sprite_x, screen_y + sprite_y, 0.0f));
		}
	}
}

frameArmature * animationFrame::ReadArmaturefromJSON(const rapidjson::Value& array_pos)
{
	//creating new struct
	frameArmature* frame_armature = new frameArmature();

	//getting variables from 
	frame_variables.name.push_back(array_pos["name"].GetString());
	frame_armature->frameRate = array_pos["frameRate"].GetFloat();

	const rapidjson::Value& skin_slot_array = array_pos["skin"][0]["slot"][0]["display"];
	for (int skin_slot_num = 0; skin_slot_num < (int)skin_slot_array.Size(); skin_slot_num++)
	{
		frame_armature->frame_order.push_back(skin_slot_array[skin_slot_num]["name"].GetString());
	}

	frame_armature->duration = array_pos["animation"][0]["duration"].GetFloat();
	frame_armature->animationName = array_pos["animation"][0]["name"].GetString();
	
	return frame_armature;
}