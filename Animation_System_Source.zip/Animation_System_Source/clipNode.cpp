#include "clipNode.h"

clipNode::clipNode(gef::SkeletonPose bindpose) : blendNode(bindpose)
{
	speedAdjustment = false;
}

clipNode::~clipNode()
{}

void clipNode::setClip(const gef::Animation* anim, gef::SkeletonPose pose)
{
	//initalising the clip player 
	clipPlayer.Init(pose);
	clipPlayer.set_looping(true);
	clipPlayer.set_clip(anim);
}

void clipNode::startInteral()
{
	//setting variable
	clipPlayer.set_anim_time(0.f);
}

bool clipNode::updateInternal(float frame_time)
{
	bool valid = false; 

	//checking if clip player has an animation
	if (clipPlayer.clip())
	{
		//if true sets variables
		if (speedAdjustment)
		{
			speedMod = (speedMax - speedMin) * blendValue;
			clipPlayer.set_playback_speed(speedMod + speedMin);
		}

		//updating variables
		clipPlayer.Update(frame_time, clipPlayer.pose());
		outputPose = clipPlayer.pose();
		valid = true;
	}

	//return bool
	return valid;
}