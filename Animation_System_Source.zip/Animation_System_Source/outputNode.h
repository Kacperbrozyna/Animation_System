#pragma once
#include "blendNode.h"

//inherited class
class outputNode : public blendNode
{
public:
	outputNode(gef::SkeletonPose bindpose);
	~outputNode();

	//update function
	bool updateInternal(float frame_time);

};

