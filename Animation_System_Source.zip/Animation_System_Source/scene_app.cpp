#include "scene_app.h"
#include <system/platform.h>
#include <graphics/sprite_renderer.h>
#include <graphics/font.h>
#include <system/debug_log.h>
#include <graphics/mesh.h>
#include <maths/math_utils.h>
#include <input/sony_controller_input_manager.h>
#include <graphics/sprite.h>
#include <input/keyboard.h>
#include "load_texture.h"



SceneApp::SceneApp(gef::Platform& platform) :
	Application(platform),
	sprite_renderer_(NULL),
	input_manager_(NULL),
	font_(NULL),
	sprite_texture_(NULL),
	player_(NULL),
	renderer_3d_(NULL),
	effector_position_(gef::Vector4::kZero)
{
	//setting variables
	rig_scale = 0.5;
	animationType = 4; 
	boneAnimation = 0; 
	frameAnimation = 0;
	is_ragdoll_simulating_ = false;
	is_kinematic_simulating_ = false;
	is_kinematic_set = false;
}

void SceneApp::Init()
{
	//setting variables
	sprite_renderer_ = gef::SpriteRenderer::Create(platform_);
	renderer_3d_ = gef::Renderer3D::Create(platform_);
	input_manager_ = gef::InputManager::Create(platform_);
	
	//calling functions to initalise 3D scene and font
	InitFont();
	SetupCamera();
	SetupLights();

	//creating and setting texture from file
	sprite_texture_ = CreateTextureFromPNG("Dragon/Dragon_tex.png", platform_);
	sprite_texture_2 = CreateTextureFromPNG("girl_tex.png", platform_);

	sprite_.set_texture(sprite_texture_);
	sprite_2.set_texture(sprite_texture_2);

	//setting the position
	spritePos = gef::Vector2(platform_.width() * 0.5f, platform_.height() * 0.5f);

	//loading in JSON from specific file
	char* tex_json = LoadJSON("Dragon/Dragon_tex.json");
	char* ske_json = LoadJSON("Dragon/Dragon_ske.json");

	char* tex_json_ = LoadJSON("girl_tex.json");
	char* ske_json_ = LoadJSON("girl_ske.json");

	//creating document variables
	rapidjson::Document tex_document;
	rapidjson::Document ske_document;

	rapidjson::Document tex_document_;
	rapidjson::Document ske_document_;

	//parse the documents
	tex_document.Parse(tex_json);
	ske_document.Parse(ske_json);

	tex_document_.Parse(tex_json_);
	ske_document_.Parse(ske_json_);

	//initalise bone and frame animations
	animation_system.initBoneAnimation(tex_document, ske_document, sprite_texture_, spritePos, gef::Vector2(rig_scale, rig_scale));
	animation_system.initFrameAnimation(tex_document_, ske_document_, &sprite_2, spritePos);

	//freeing up the documents
	free(tex_json);
	free(ske_json);
	free(tex_json_);
	free(ske_json_);

	//loading model in
	player_ = animation_system.animation3D.loadTargetModel(platform_, "human/human.scn", player_);

	//initalise 3D animation
	animation_system.init3Danimation(&platform_, player_);

	//loading in animation
	animation_system.animation3D.loadTargetAnimation(platform_, "human/xbot@walking_inplace.scn", "", "walking");
	animation_system.animation3D.loadTargetAnimation(platform_, "human/xbot@running_inplace.scn", "", "running");
	animation_system.animation3D.loadTargetAnimation(platform_, "human/ybotidle.scn", "", "idle");
	animation_system.animation3D.loadTargetAnimation(platform_, "human/ybotjump.scn", "", "jumping");

	//initalising blend tree
	animation_system.animation3D.InitBlendTree(player_);
}

void SceneApp::CleanUp()
{
	delete sprite_texture_;
	sprite_texture_ = NULL;

	delete input_manager_;
	input_manager_ = NULL;

	CleanUpFont();

	delete sprite_renderer_;
	sprite_renderer_ = NULL;
}

bool SceneApp::Update(float frame_time)
{
	fps_ = 1.0f / frame_time;

	//creating new variables
	bool mb_down = false; 
	gef::Vector2 mouse_position(gef::Vector2::kZero);

	//updating input manager
	if (input_manager_)
	{
		input_manager_->Update();

		// keyboard input
		gef::Keyboard* keyboard = input_manager_->keyboard();

		//calling functions if keys are pressed
		if (keyboard->IsKeyPressed(gef::Keyboard::KC_NUMPADPLUS))
		{
			switch (animationType)
			{
			case 2:
			case 1:
			case 0: animation_system.changeBlendTreeInput(0, true);
				break;
			default:
				break;
			}
		}

		if (keyboard->IsKeyPressed(gef::Keyboard::KC_NUMPADMINUS))
		{
			switch (animationType)
			{
			case 2:
			case 1:
			case 0: animation_system.changeBlendTreeInput(1, false);
				break;
			default:
				break;
			}
		}

		if (keyboard->IsKeyPressed(gef::Keyboard::KC_SPACE))
		{
			is_ragdoll_simulating_ = !is_ragdoll_simulating_;
		}

		if (keyboard->IsKeyPressed(gef::Keyboard::KC_NUMPADENTER))
		{
			is_kinematic_set = !is_kinematic_set;
		}

		if (keyboard->IsKeyPressed(keyboard->KC_DOWN))
		{
			animationType--;

			if (animationType < 0)
			{
				animationType = 0;
			}
		}

		if (keyboard->IsKeyPressed(keyboard->KC_UP))
		{
			animationType++;

			if (animationType > 4)
			{
				animationType = 4;
			}
		}

		if (keyboard->IsKeyPressed(keyboard->KC_RIGHT))
		{
			switch (animationType)
			{
			case 4:frameAnimation++;
				if (frameAnimation > 4)
				{
					frameAnimation = 4;
				}
				break;
			case 3: boneAnimation++;
				if (boneAnimation > 3)
				{
					boneAnimation = 3;
				}
				break;
			case 2:
				animation_system.animation3D.linearblend_nodes.at(0)->speed += 0.01;

			if (animation_system.animation3D.linearblend_nodes.at(0)->speed > 1)
			{
				animation_system.animation3D.linearblend_nodes.at(0)->speed = 1;
			}
				break;
			case 1: animation_system.animation3D.linearblend_nodes.at(1)->speed += 0.01;

				if (animation_system.animation3D.linearblend_nodes.at(1)->speed > 1)
				{
					animation_system.animation3D.linearblend_nodes.at(1)->speed = 1;
				}
				break;
			case 0: animation_system.animation3D.linearblend_nodes.at(2)->speed += 0.01;

				if (animation_system.animation3D.linearblend_nodes.at(2)->speed > 1)
				{
					animation_system.animation3D.linearblend_nodes.at(2)->speed = 1;
				}
				break;
			default:
				break;
			}
		}

		if (keyboard->IsKeyPressed(keyboard->KC_LEFT))
		{
			switch (animationType)
			{
			case 4:frameAnimation--;
				if (frameAnimation < 0)
				{
					frameAnimation = 0;
				};
				break;
			case 3: boneAnimation--;
				if (boneAnimation < 0)
			{
				boneAnimation = 0;
			}
				break;
			case 2: animation_system.animation3D.linearblend_nodes.at(0)->speed -= 0.01;

			if (animation_system.animation3D.linearblend_nodes.at(0)->speed < 0)
			{
				animation_system.animation3D.linearblend_nodes.at(0)->speed = 0;
			}
				  break;
			case 1: animation_system.animation3D.linearblend_nodes.at(1)->speed -= 0.01;

				if (animation_system.animation3D.linearblend_nodes.at(1)->speed < 0)
				{
					animation_system.animation3D.linearblend_nodes.at(1)->speed = 0;
				}
				break;
			case 0: animation_system.animation3D.linearblend_nodes.at(2)->speed -= 0.01;

				if (animation_system.animation3D.linearblend_nodes.at(2)->speed < 0)
				{
					animation_system.animation3D.linearblend_nodes.at(2)->speed = 0;
				}
				break;
			default:
				break;
			}
		}

		//setting variables
		mouse_position = input_manager_->touch_manager()->mouse_position();
		mb_down = input_manager_->touch_manager()->is_button_down(1);
	
		//checking if mouse button is pressed
		if (mb_down)
		{
			gef::Vector4 mouse_ray_start_point, mouse_ray_direction;
			GetScreenPosRay(mouse_position, renderer_3d_->projection_matrix(), renderer_3d_->view_matrix(), mouse_ray_start_point, mouse_ray_direction, (float)platform_.width(), (float)platform_.height(), ndc_zmin_);

			if (RayPlaneIntersect(mouse_ray_start_point, mouse_ray_direction, gef::Vector4(0.0f, 0.0f, 0.0f), gef::Vector4(0.0f, 0.0f, 1.0f), effector_position_))
			{
				is_kinematic_simulating_ = true;
			}
		}
		else
		{
			is_kinematic_simulating_ = false;
		}
	}

	//update animations depening on variable
	switch (animationType)
	{
	case 4: animation_system.updateFrames(frame_time, frameAnimation);
		break;
	case 3: animation_system.updateBones(frame_time, boneAnimation);
		break;
	case 2:
	case 1: 
	case 0:animation_system.update3D(frame_time, player_, is_ragdoll_simulating_, is_kinematic_simulating_, effector_position_, is_kinematic_set);
		break;
	default:
		break;
	}

	return true;
}




void SceneApp::Render()
{
	//setting up 3D views
	gef::Matrix44 projection_matrix;
	gef::Matrix44 view_matrix;
	projection_matrix = platform_.PerspectiveProjectionFov(camera_fov_, (float)platform_.width() / (float)platform_.height(), near_plane_, far_plane_);
	view_matrix.LookAt(camera_eye_, camera_lookat_, camera_up_);

	//render depending on variable
	switch (animationType)
	{
	case 4: sprite_renderer_->Begin(); 
			animation_system.renderFrames(sprite_renderer_, sprite_2, spritePos);
			DrawHUD();
			sprite_renderer_->End();
		break;
	case 3: sprite_renderer_->Begin(); 
			animation_system.renderBones(sprite_renderer_);
			DrawHUD();
			sprite_renderer_->End();
		break;
	case 2:
	case 1:	
	case 0: renderer_3d_->set_projection_matrix(projection_matrix);
		renderer_3d_->set_view_matrix(view_matrix);
		animation_system.render3D(renderer_3d_, player_);
		sprite_renderer_->Begin(false);
		DrawHUD();
		sprite_renderer_->End();
	break;
	default:
		break;
	}
}

void SceneApp::InitFont()
{
	font_ = new gef::Font(platform_);
	font_->Load("comic_sans");
}

void SceneApp::CleanUpFont()
{
	delete font_;
	font_ = NULL;
}

void SceneApp::DrawHUD()
{
	if(font_)
	{
		//render specific font depending on input
		switch (animationType)
		{
		case 4: font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 480.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "Frame Animation: %i", frameAnimation + 1);
			break;
		case 3: font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 480.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "Dragon Animation: %i", boneAnimation + 1);
			break;
		case 2: 
			font_->RenderText(sprite_renderer_, gef::Vector4(940.0f, 420.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "walk/run Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(0)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 450.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "idle/jump Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(1)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 480.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "first/second blend: %.2f", animation_system.animation3D.linearblend_nodes.at(2)->speed);
			  break;
		case 1: 
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 420.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "walk/run Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(0)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(940.0f, 450.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "idle/jump Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(1)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 480.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "first/second blend: %.2f", animation_system.animation3D.linearblend_nodes.at(2)->speed);
			break;
		case 0:
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 420.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "walk/run Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(0)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 450.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "idle/jump Blend: %.2f", animation_system.animation3D.linearblend_nodes.at(1)->speed);
			font_->RenderText(sprite_renderer_, gef::Vector4(940.0f, 480.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "first/second blend: %.2f", animation_system.animation3D.linearblend_nodes.at(2)->speed);
			break;
		default:
			break;
		}
		// display frame rate
		font_->RenderText(sprite_renderer_, gef::Vector4(960.0f, 510.0f, -0.9f), 1.0f, 0xffffffff, gef::TJ_RIGHT, "FPS: %.1f", fps_);
	}
}

void SceneApp::SetupLights()
{
	//initialise lights
	gef::PointLight default_point_light;
	default_point_light.set_colour(gef::Colour(0.7f, 0.7f, 1.0f, 1.0f));
	default_point_light.set_position(gef::Vector4(-300.0f, -500.0f, 100.0f));

	gef::Default3DShaderData& default_shader_data = renderer_3d_->default_shader_data();
	default_shader_data.set_ambient_light_colour(gef::Colour(0.5f, 0.5f, 0.5f, 1.0f));
	default_shader_data.AddPointLight(default_point_light);
}

void SceneApp::SetupCamera()
{
	// initialise the camera settings
	camera_eye_ = gef::Vector4(-1.0f, 1.0f, 4.0f);
	camera_lookat_ = gef::Vector4(0.0f, 1.0f, 0.0f);
	camera_up_ = gef::Vector4(0.0f, 1.0f, 0.0f);
	camera_fov_ = gef::DegToRad(45.0f);
	near_plane_ = 0.01f;
	far_plane_ = 1000.f;
}


