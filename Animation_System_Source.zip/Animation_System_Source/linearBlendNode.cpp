#include "linearBlendNode.h"

linearBlendNode::linearBlendNode(gef::SkeletonPose bindpose) : blendNode(bindpose)
{
	//setting variables
	inputs.resize(2);
	speed = 0.f;
}

linearBlendNode::~linearBlendNode()
{}

bool linearBlendNode::updateInternal(float frame_time)
{
	//setting values
	inputs[0].node->blendValue = speed;
	inputs[1].node->blendValue = speed;

	//blending between poses
	outputPose.Linear2PoseBlend(inputs[0].node->outputPose, inputs[1].node->outputPose, speed);

	//return bool
	return true;
}
