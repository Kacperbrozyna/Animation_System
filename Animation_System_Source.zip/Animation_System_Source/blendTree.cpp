#include "blendTree.h"

blendTree::blendTree(gef::SkeletonPose bindpose) : output(bindpose)
{
}


blendTree::~blendTree()
{
}

void blendTree::init(const gef::SkeletonPose& bindPose_)
{

	//setting variable
	output.outputPose = bindPose_;
}

void blendTree::cleanUp()
{
}

void blendTree::start()
{
	//calling function
	output.start();
}

void blendTree::update(float frame_time)
{
	//setting variable from function
	bool valid = output.update(frame_time);
}