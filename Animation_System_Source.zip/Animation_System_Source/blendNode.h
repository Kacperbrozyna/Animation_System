#pragma once
#include <animation/animation.h>
#include <graphics/skinned_mesh_instance.h>

#include <vector>

//prototyping class
class blendNode;

//struct 
struct BlendNodeInput
{
	blendNode* node;
	BlendNodeInput() :
		node(nullptr)
	{
	}
};

//base class
class blendNode
{
public:

	blendNode(gef::SkeletonPose bindpose);
	~blendNode();
	
	//functions to start and override start
	void start();
	virtual void startInteral() {}

	//functions to update and override update
	bool update(float frame_time);
	virtual bool updateInternal(float frame_time) = 0;
	
	//fucntions to set inputs
	void setInput(int inputNum, blendNode* node);
	
	//creating variables
	std::vector<BlendNodeInput> inputs;
	gef::SkeletonPose outputPose;
	float blendValue = 0;
};

