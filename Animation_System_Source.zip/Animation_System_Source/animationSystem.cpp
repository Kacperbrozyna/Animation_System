#include "animationSystem.h"

std::string model_name("human");

animationSystem::animationSystem()
{}

animationSystem::~animationSystem()
{}

void animationSystem::initBoneAnimation(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Texture* sprite_texture, gef::Vector2 screen_pos, gef::Vector2 scale)
{
	//calling 2d bone animation initalisation
	animation_bones.Init(tex_document, ske_document, sprite_texture, screen_pos, scale);
}

void animationSystem::initFrameAnimation(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Sprite* sprite_, gef::Vector2 spritePos)
{
	//calling 2d frame animation initalisation
	animation_frame.init(tex_document, ske_document, sprite_, spritePos);
}

void animationSystem::init3Danimation(gef::Platform* platform_, gef::SkinnedMeshInstance* player_)
{
	//setting variable
	primitive_builder_ = new PrimitiveBuilder(*platform_);

	//initalising 3d animations // physics worlds and ragdoll
	animation3D.init();
	InitPhysicsWorld();
	CreateRigidBodies();
	InitRagdoll(player_);

	//setting variables
	animation3D.blendedPose = animation3D.blend_tree->output.outputPose;
	previousPose = animation3D.blendedPose;

	//initalising kinematic 
	kinematicInit();
}

void animationSystem::kinematicInit()
{
	//setting variables for each bone 
	bone_indices.push_back(16); // left arm
	bone_indices.push_back(17); // left forearm
	bone_indices.push_back(18); // left hand
	bone_indices.push_back(19); // left hand index 1

	//constraints for each bone
	constraints.push_back(std::pair<float, float>(0.0f, gef::DegToRad(1)));
	constraints.push_back(std::pair<float, float>(0.0f, gef::DegToRad(1)));
	constraints.push_back(std::pair<float, float>(0.0f, gef::DegToRad(1)));
	constraints.push_back(std::pair<float, float>(0.0f, gef::DegToRad(1)));

	//priority for each bone added
	priority_bones.push_back(0);
	priority_bones.push_back(1);
	priority_bones.push_back(2);
}

void animationSystem::updateBones(float frame_time, int animNumb)
{
	//updating bone animation
	animation_bones.Update(frame_time, animNumb);
}

void animationSystem::updateFrames(float frame_time, int animNumb)
{
	//updating frame animation
	animation_frame.update(frame_time, animNumb);
}

void animationSystem::update3D(float frame_time, gef::SkinnedMeshInstance* skinnedmesh, bool is_ragdoll_simulating, bool is_kinematic_simulating, gef::Vector4 effectorPos, bool is_kinematic_set)
{
	//updating 3d animation
	if (skinnedmesh && rag_doll)
	{
		//updating the blend tree and setting pose
		animation3D.blend_tree->update(frame_time);
		animation3D.blendedPose = animation3D.blend_tree->output.outputPose;

		//updating physics if ragdoll is active
		if (is_ragdoll_simulating)
		{
			UpdatePhysicsWorld(frame_time);

			rag_doll->UpdatePoseFromRagdoll();

			//updating bones if kinematic is active
			if (is_kinematic_simulating)
			{
				CalculateCCD(rag_doll->pose(), *skinnedmesh, effectorPos, bone_indices, constraints, priority_bones);
			}

			//updating the bones from previous calculations
			skinnedmesh->UpdateBoneMatrices(rag_doll->pose());
		}
		else
		{
			//updating bones if kinematic is active
			if (is_kinematic_set)
			{
				CalculateCCD(animation3D.blendedPose, *skinnedmesh, effectorPos, bone_indices, constraints, priority_bones);
			}

			//updating pose
			skinnedmesh->UpdateBoneMatrices(animation3D.blendedPose);
			rag_doll->set_pose(animation3D.blendedPose);
		    rag_doll->UpdateRagdollFromPose(previousPose, frame_time);
		}
		
		//setting variable
		previousPose = animation3D.blendedPose;
	}
}

void animationSystem::changeBlendTreeInput(int nodeNum, bool blend)
{
	//changing input of the blend tree
	animation3D.changeBlendTreeInput(nodeNum, blend);
}

void animationSystem::renderBones(gef::SpriteRenderer* sprite_renderer)
{
	//render the bone animation
	animation_bones.Render(sprite_renderer);
}

void animationSystem::renderFrames(gef::SpriteRenderer* sprite_renderer, gef::Sprite sprite_, gef::Vector2 spritePos)
{
	//render frame animation
	animation_frame.render(sprite_renderer, sprite_, spritePos);
}

void animationSystem::render3D(gef::Renderer3D* renderer_3d_, gef::SkinnedMeshInstance * skinnedMesh)
{
	//render meshes if meshes are valid
	renderer_3d_->Begin();

	if (skinnedMesh)
	{
		renderer_3d_->DrawSkinnedMesh(*skinnedMesh, skinnedMesh->bone_matrices());
	}

	renderer_3d_->DrawMesh(floor_gfx_);

	renderer_3d_->End();
}

void animationSystem::InitPhysicsWorld()
{
	/// collision configuration contains default setup for memory , collision setup . Advanced users can create their own configuration .
	btDefaultCollisionConfiguration* collision_configuration = new btDefaultCollisionConfiguration();

	/// use the default collision dispatcher . For parallel processing you can use a diffent dispatcher(see Extras / BulletMultiThreaded)
	dispatcher_ = new btCollisionDispatcher(collision_configuration);

	/// btDbvtBroadphase is a good general purpose broadphase . You can also try out btAxis3Sweep .
	overlapping_pair_cache_ = new btDbvtBroadphase();

	/// the default constraint solver . For parallel processing you can use a different solver (see Extras / BulletMultiThreaded)
	solver_ = new btSequentialImpulseConstraintSolver;

	dynamics_world_ = new btDiscreteDynamicsWorld(dispatcher_, overlapping_pair_cache_, solver_, collision_configuration);
	dynamics_world_->setGravity(btVector3(0, -9.8f, 0));
}

void animationSystem::CleanUpPhysicsWorld()
{

	for (int i = dynamics_world_->getNumConstraints() - 1; i >= 0; i--)
	{
		btTypedConstraint* constraint = dynamics_world_->getConstraint(i);
		dynamics_world_->removeConstraint(constraint);
		delete constraint;
	}


	// remove the rigidbodies from the dynamics world and delete them
	for (int i = dynamics_world_->getNumCollisionObjects() - 1; i >= 0; i--)
	{
		btCollisionObject* obj = dynamics_world_->getCollisionObjectArray()[i];
		btRigidBody* body = btRigidBody::upcast(obj);
		if (body && body->getMotionState())
		{
			delete body->getMotionState();
		}
		dynamics_world_->removeCollisionObject(obj);
		delete obj;
	}

	// delete collision shapes
	for (int j = 0; j < collision_shapes_.size(); j++)
	{
		btCollisionShape* shape = collision_shapes_[j];
		collision_shapes_[j] = 0;
		delete shape;
	}

	// delete dynamics world
	delete dynamics_world_;

	// delete solver
	delete solver_;

	// delete broadphase
	delete overlapping_pair_cache_;

	// delete dispatcher
	delete dispatcher_;

	dynamics_world_ = NULL;
	solver_ = NULL;
	overlapping_pair_cache_ = NULL;
	dispatcher_ = NULL;

	// next line is optional : it will be cleared by the destructor when the array goes out of scope
	collision_shapes_.clear();
}

void animationSystem::UpdatePhysicsWorld(float delta_time)
{
	const btScalar simulation_time_step = 1.0f / 60.0f;
	const int max_sub_steps = 1;
	dynamics_world_->stepSimulation(simulation_time_step, max_sub_steps);
}

void animationSystem::CreateRigidBodies()
{
	//the ground is a cube of side 100 at position y = 0.
	{
		btVector3 groundHalfExtents(btScalar(50.), btScalar(1.), btScalar(50.));
		btCollisionShape* groundShape = new btBoxShape(groundHalfExtents);

		collision_shapes_.push_back(groundShape);

		btTransform groundTransform;
		groundTransform.setIdentity();
		groundTransform.setOrigin(btVector3(0, -groundHalfExtents.y(), 0));

		btScalar mass(0.);

		//rigidbody is dynamic if and only if mass is non zero, otherwise static
		bool isDynamic = (mass != 0.f);

		btVector3 localInertia(0, 0, 0);
		if (isDynamic)
			groundShape->calculateLocalInertia(mass, localInertia);

		//using motionstate is optional, it provides interpolation capabilities, and only synchronizes 'active' objects
		btDefaultMotionState* myMotionState = new btDefaultMotionState(groundTransform);
		btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, myMotionState, groundShape, localInertia);
		btRigidBody* body = new btRigidBody(rbInfo);

		//add the body to the dynamics world
		dynamics_world_->addRigidBody(body);

		floor_mesh_ = primitive_builder_->CreateBoxMesh(gef::Vector4(groundHalfExtents.x(), groundHalfExtents.y(), groundHalfExtents.z()));
		floor_gfx_.set_mesh(floor_mesh_);
		floor_gfx_.set_transform(btTransform2Matrix(groundTransform));
	}

	//	if(0)
	{
		//create a dynamic rigidbody

		const btScalar  sphereRadius = 1.f;
		btCollisionShape* colShape = new btSphereShape(sphereRadius);

		collision_shapes_.push_back(colShape);

		/// Create Dynamic Objects
		btTransform startTransform;
		startTransform.setIdentity();

		btScalar mass(1.f);

		//rigidbody is dynamic if and only if mass is non zero, otherwise static
		bool isDynamic = (mass != 0.f);

		btVector3 localInertia(0, 0, 0);
		if (isDynamic)
			colShape->calculateLocalInertia(mass, localInertia);

		startTransform.setOrigin(btVector3(2, 10, 0));

		//using motionstate is recommended, it provides interpolation capabilities, and only synchronizes 'active' objects
		btDefaultMotionState* myMotionState = new btDefaultMotionState(startTransform);
		btRigidBody::btRigidBodyConstructionInfo rbInfo(mass, myMotionState, colShape, localInertia);
		btRigidBody* body = new btRigidBody(rbInfo);

		dynamics_world_->addRigidBody(body);
	}
}

void animationSystem::CleanUpRigidBodies()
{
	delete floor_mesh_;
	floor_mesh_ = NULL;
}

void animationSystem::InitRagdoll(gef::SkinnedMeshInstance* player_)
{
	if (player_->bind_pose().skeleton())
	{
		rag_doll = new Ragdoll();
		rag_doll->set_scale_factor(0.01f);

		std::string ragdoll_filename;
		ragdoll_filename = model_name + "/ragdoll.bullet";

		rag_doll->Init(player_->bind_pose(), dynamics_world_, ragdoll_filename.c_str());
	}
}

