#pragma once

#include <vector>
#include "subTexture.h"
#include <map>
#include <string>

class textureAtlas
{
public:
	textureAtlas();
	~textureAtlas();

	//function to create transform
	void setTransform(gef::Vector2 sprite_pos, gef::Vector2 scale);

	//creating variables
	std::vector<subTexture> subTextures;

	std::string name;
	float width, height;

	gef::Matrix33 transform;
	gef::Matrix33 scalee;
	gef::Matrix33 translation;
};

