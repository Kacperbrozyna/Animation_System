#pragma once
#include "textureAtlas.h"
#include "rapidjson\document.h"
#include <graphics/sprite.h>
#include <graphics/sprite_renderer.h>

//structs to store variables
struct frameArmature
{
	float duration;
	float frameRate; 
	std::vector<std::string> frame_order;
	std::string animationName;
};

struct variableFrame
{
	float animation_timer = 0;
	int frame = 0;
	textureAtlas* text_atlas;
	std::vector<frameArmature*> armature;
	std::vector<std::string> name;
};


class animationFrame
{
public:
	animationFrame();
	~animationFrame();

	//functions to initalise, update and render
	void init(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Sprite* sprite_, gef::Vector2 spritePos);
	void update(float frame_time, int animNumb);
	void render(gef::SpriteRenderer* sprite_renderer, gef::Sprite sprite_, gef::Vector2 spritePos);

	//function to create texture atlas from reading the JSON file
	textureAtlas* ReadTextureAtlasFromJSON(rapidjson::Document& tex_document);

	//function to create subtexture from reading the JSON file
	subTexture* ReadSubTextureFromJSON(const rapidjson::Value& subtexture_array);

	//function to set sprite variables
	void SetSpriteSizeandPositionFrame(gef::Sprite* sprite, float screen_x, float screen_y, textureAtlas* texture_atlas, std::string frame_order_name);

	//function to fill armture struct from JSON file
	frameArmature * ReadArmaturefromJSON(const rapidjson::Value& array_pos);

	//creating variables
	variableFrame frame_variables;
	int animationNumb;
};

