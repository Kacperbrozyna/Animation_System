#pragma once
#include "blendNode.h"

//inherited class
class linearBlendNode : public blendNode
{
public:
	linearBlendNode(gef::SkeletonPose bindpose);
	~linearBlendNode();

	//override update function
	bool updateInternal(float frame_time) override;

	//creating variable
	float speed;
};

