#pragma once
#include "motion_clip_player.h"
#include <graphics/skinned_mesh_instance.h>
#include <graphics/scene.h>
#include <system/platform.h>
#include <animation/animation.h>
#include <graphics/mesh.h>
#include <map>
#include <string>
#include "blendTree.h"
#include "clipNode.h"
#include "linearBlendNode.h"

namespace gef
{
	class Scene;
	class Mesh;
	class Skeleton;
	class Animation;
	class Platform;
}

class anim3D
{
public:

	//functions to initalise and cleanup
	anim3D();
	void init();
	void cleanup();

	//function to load in an animation
	void loadTargetAnimation(gef::Platform& platform, const char* anime_fileName, const char* animName, std::string animationIndex);

	//function initalise blend tree
	void InitBlendTree(gef::SkinnedMeshInstance* skinnedMesh);

	//function to change blend tree output
	void changeBlendTreeInput(int nodeNum, bool blend);
	
	//function to load model and animation
	gef::Animation* LoadAnimation(const char* anim_scene_filename, const char* anim_name, gef::Platform& platform);
	gef::SkinnedMeshInstance* loadTargetModel(gef::Platform& platform, const char* fileName, gef::SkinnedMeshInstance* skinnedMesh);

	//getter functions
	gef::Skeleton* GetSkeleton(gef::Scene* scene);
	gef::Mesh * GetMesh(gef::Scene* scene, gef::Platform &platform);

	//functions to setup blend nodes
	linearBlendNode* SetupBlend_Clips(gef::SkinnedMeshInstance* skinnedMesh, std::string animName, std::string animName2, bool speedAdjustment);
	linearBlendNode* SetupBlend_Nodes(gef::SkinnedMeshInstance* skinnedMesh , linearBlendNode* linear_blend_node_, linearBlendNode* linear_blend_node_2);

	//creating variables
	std::map<std::string, gef::Animation> animations;
	typedef std::pair<std::string, gef::Animation> str_animations;
	gef::Animation* currentAnimation;
	gef::SkeletonPose blendedPose;
	blendTree * blend_tree;
	std::vector<linearBlendNode*> linearblend_nodes;
	std::vector<std::string> animNames;
};

