#include "subTexture.h"



subTexture::subTexture()
{

}


subTexture::~subTexture()
{
}

void subTexture::BuildTransform()
{
	//sets identity
	transform.SetIdentity();
	translation.SetIdentity();
	scale.SetIdentity();
	
	//calculates new variables
	float x = subWidth * 0.5f - (subFrameWidth * 0.5f + subFrameX);
	float y = subHeight * 0.5f - (subFrameHeight * 0.5f + subFrameY);

	//setting variables
	translation.SetTranslation(gef::Vector2(x, y));
	scale.Scale(gef::Vector2(subWidth, subHeight));
	transform = scale * translation;
}

