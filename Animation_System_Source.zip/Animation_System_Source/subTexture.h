#pragma once
#include <maths/vector2.h>
#include <maths/matrix33.h>
#include <string>

class subTexture
{
public:
	subTexture();
	~subTexture();

	//function to build transform
	void BuildTransform();

	//creating variables
	std::string subName;
	float subWidth, subHeight, subFrameWidth, subFrameHeight, subX, subY, subFrameX, subFrameY;

	gef::Matrix33 translation;
	gef::Matrix33 transform;
	gef::Matrix33 scale;
};

