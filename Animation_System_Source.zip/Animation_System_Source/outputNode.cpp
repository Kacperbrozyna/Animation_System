#include "outputNode.h"

outputNode::outputNode(gef::SkeletonPose bindpose) : blendNode(bindpose)
{
	//changing variable
	inputs.resize(1);
}

outputNode::~outputNode()
{
}

bool outputNode::updateInternal(float frame_time)
{
	//setting variable
	outputPose = inputs[0].node->outputPose;

	//returning bool
	return true;
}