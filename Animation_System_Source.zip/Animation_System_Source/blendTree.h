#pragma once
#include <graphics/skinned_mesh_instance.h>
#include "outputNode.h"

class blendTree 
{
public:
	blendTree(gef::SkeletonPose bindpose);
	~blendTree();

	//functions to initalise, cleanup, start and update
	void init(const gef::SkeletonPose & bindPose);
	void cleanUp();
	void start();
	void update(float frame_time);

	//creating variable
	outputNode output;
};

