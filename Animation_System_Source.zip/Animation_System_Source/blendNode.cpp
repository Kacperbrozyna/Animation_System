#include "blendNode.h"

blendNode::blendNode(gef::SkeletonPose bindpose) 
{
	//setting variable
	outputPose = bindpose;
}

blendNode::~blendNode()
{
}

void blendNode::start()
{
	//loop for the size of the inputs
	for (int inputNum = 0; inputNum < inputs.size(); inputNum++)
	{
		//calling start function for each input node
		BlendNodeInput& input = inputs[inputNum];
		if (input.node)
		{
			input.node->start();
		}
	}

	//function call
	startInteral();
}

void blendNode::setInput(int inputNum, blendNode* node)
{
	//check to see if valid and set variable
	if (node && inputNum < inputs.size())
	{
		inputs[inputNum].node = node;
	}
}

bool blendNode::update(float frame_time)
{
	//checking if valud then update the node associated
	bool all_inputs_valid = true;
	if (inputs.size() > 0)
	{
		for (int inputNum = 0; inputNum < inputs.size(); ++inputNum)
		{
			BlendNodeInput& input = inputs[inputNum];
			bool inputValid;

			if (input.node)
			{
				inputValid = input.node->update(frame_time);
			}
			else
			{
				inputValid = false;
			}

			if (!inputValid && all_inputs_valid)
			{
				all_inputs_valid = false;
			}
		}
	}
	
	//update the output if the inputs are valid
	bool outputValid = false; 
	if (all_inputs_valid)
	{
		outputValid = updateInternal(frame_time);
	}

	//return bool
	return outputValid;
}