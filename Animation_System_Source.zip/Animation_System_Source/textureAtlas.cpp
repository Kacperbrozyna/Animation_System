#include "textureAtlas.h"



textureAtlas::textureAtlas()
{
}


textureAtlas::~textureAtlas()
{
}

void textureAtlas::setTransform(gef::Vector2 sprite_pos, gef::Vector2 scale)
{
	//setting identity and variables
	transform.SetIdentity();
	transform.Scale(gef::Vector2(scale));
	transform.SetTranslation(gef::Vector2(sprite_pos.x, sprite_pos.y));
}