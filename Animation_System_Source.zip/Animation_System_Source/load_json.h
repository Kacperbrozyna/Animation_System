#ifndef _JSON_H
#define _JSON_H

char* LoadJSON(const char* filename);

#endif // _JSON_H