#pragma once
#include "armatureParser.h"
#include "animationFrame.h"
#include "anim3D.h"
#include <graphics/renderer_3d.h>
#include "ragdoll.h"
#include "primitive_builder.h"
#include "ccd.h"

class animationSystem
{
public:

	animationSystem();
	~animationSystem();

	//functions to initalise
	void initFrameAnimation(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Sprite* sprite_, gef::Vector2 spritePos);
	void initBoneAnimation(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Texture* sprite_texture, gef::Vector2 screen_pos, gef::Vector2 scale);
	void init3Danimation(gef::Platform* platform_, gef::SkinnedMeshInstance* player_);
	void kinematicInit();

	//update functions
	void updateBones(float frame_time, int animNumb);
	void updateFrames(float frame_time, int animNumb);
	void update3D(float frame_time, gef::SkinnedMeshInstance* skinnedmesh, bool is_ragdoll_simulating, bool is_kinetic_simulating, gef::Vector4 effectorPos, bool is_kinetic_set);

	//change blend tree input
	void changeBlendTreeInput(int nodeNum, bool blend);

	//render functions
	void renderBones(gef::SpriteRenderer * sprite_renderer);
	void renderFrames(gef::SpriteRenderer* sprite_renderer, gef::Sprite sprite_, gef::Vector2 spritePos);
	void render3D(gef::Renderer3D* renderer_3d_, gef::SkinnedMeshInstance* skinnedMesh);

	//functions for rigid bodies and physics
	void InitRagdoll(gef::SkinnedMeshInstance* player_);
	void InitPhysicsWorld();
	void CleanUpPhysicsWorld();
	void UpdatePhysicsWorld(float delta_time);
	void CreateRigidBodies();
	void CleanUpRigidBodies();

	//creating class objects
	armatureParser animation_bones;
	animationFrame animation_frame;
	anim3D animation3D;
	Ragdoll* rag_doll;

	// ragdoll/physics specific variables
	btDiscreteDynamicsWorld* dynamics_world_;
	btSequentialImpulseConstraintSolver* solver_;
	btBroadphaseInterface* overlapping_pair_cache_;
	btCollisionDispatcher* dispatcher_;
	btAlignedObjectArray<btCollisionShape*> collision_shapes_;
	PrimitiveBuilder* primitive_builder_;

	//creating floor
	gef::Mesh* floor_mesh_;
	gef::MeshInstance floor_gfx_;

	//holding previous pose variable
	gef::SkeletonPose previousPose;

	//creating kinematic variables
	std::vector<int> bone_indices;
	std::vector<std::pair<float, float>> constraints;
	std::vector<int> priority_bones;
};

