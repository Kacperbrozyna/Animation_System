#pragma once
#include <graphics/sprite.h>
#include <graphics/sprite_renderer.h>
#include "maths/math_utils.h"
#include <vector>

#include "textureAtlas.h"
#include "rapidjson\document.h"

//creating structs to hold variables
struct TranslationKey
{
	float time_to_next_key, start_time;
	gef::Vector2 translation;
};

struct RotationKey
{
	float time_to_next_key, start_time, rotation;
};

struct BoneKey
{
	std::string name;
	std::vector<TranslationKey*> translation_keys;
	std::vector<RotationKey*> rotation_keys;
};

struct Slot
{
	std::string name;
	std::string parentName;
	gef::Matrix33 final_transform;
};

struct SkinSlot
{
	std::string name;
	std::string Partname;
	gef::Matrix33 offset_transform;
	gef::Matrix33 rotation;
	gef::Matrix33 translation;
	float x, y, rot;
};

struct Bone
{
	std::string name;
	std::string parent;
	gef::Matrix33 modified_local_transform;
	gef::Vector2 local_bone_pos;
	float local_rot;
	gef::Matrix33 world_transform;
};

struct Animation
{
	float duration;
	std::string name;
	std::vector<BoneKey*> bone_keys;
};

struct Armature
{
	float frame_rate;
	std::string name;
};

struct SpriteAnimation
{
	float frame_rate;
	std::string name;
	std::vector<Bone*> bones;
	std::vector<Slot*> slots;
	std::vector<SkinSlot*> Skinslots;
	std::vector<Animation*> animations;
	Animation* current_animation;
	Armature* armature;
	textureAtlas* text_atlas;
	int frame_index;
};

//inherited from sprite
class armatureParser : gef::Sprite
{
public:
	armatureParser();
	~armatureParser();

	//functions to initalise, update and render
	void Init(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Texture* sprite_texture, gef::Vector2 screen_pos, gef::Vector2 scale);
	void Update(float dt, int animationNum);
	void Render(gef::SpriteRenderer* sprite_renderer);

	//getter
	SpriteAnimation* getSpriteAnimation() { return spriteAnim; }

	//variable
	typedef std::pair<std::string, subTexture> str_subtex;

private:

	//functions to read variables from JSON
	textureAtlas* armatureParser::ReadTextureAtlasFromJSON(rapidjson::Document& tex_document);
	subTexture* armatureParser::ReadSubTextureFromJSON(const rapidjson::Value& array_pos);
	Armature* ReadArmatureFromJSON(const rapidjson::Value& array_pos);
	Animation* ReadAnimationFromJSON(const rapidjson::Value& array_pos);
	SkinSlot* ReadSkinSlotFromJSON(const rapidjson::Value& array_pos);
	Bone* ReadBoneFromJSON(const rapidjson::Value& array_pos);
	Slot* ReadSlotFromJSON(const rapidjson::Value& array_pos);
	TranslationKey* ReadTranslationKeyDataFromJSON(const rapidjson::Value& array_pos);
	RotationKey* ReadRotationKeyDataFromJSON(const rapidjson::Value& array_pos);

	//lerp functions
	gef::Vector2 lerp(gef::Vector2 start_pos, gef::Vector2 end_pos, float time);
	float lerp(float startAngle, float endAngle, float time);

	//functions to calculate transforms
	void CalculateWorldBoneTransform(Animation* anim, int current_frame);
	void CalculateFinalTransform();
	void SetSpriteSizeandPositionFrame(gef::Sprite* sprite, float screen_x, float screen_y, textureAtlas* texture_atlas, std::string name);

	//creating variables
	float sprite_speed, elapsed_time; 
	SpriteAnimation* spriteAnim;
	std::vector<Sprite> sprites;
	gef::Vector2 screenPos;
};

