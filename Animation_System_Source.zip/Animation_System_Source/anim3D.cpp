#include "anim3D.h"

anim3D::anim3D()
{
	
}

void anim3D::init()
{
	//setting variable
	currentAnimation = NULL;
}

gef::SkinnedMeshInstance* anim3D::loadTargetModel(gef::Platform &platform, const char* fileName, gef::SkinnedMeshInstance* skinnedMesh)
{
	//creating new variables
	gef::Scene* model;
	gef::Mesh* mesh; 
	model = new gef::Scene;

	//reading and setting model from file
	model->ReadSceneFromFile(platform, fileName);
	model->CreateMaterials(platform);
	mesh = GetMesh(model, platform);

	//getting and checking skeleton
	gef::Skeleton* skeleton = GetSkeleton(model);
	if (skeleton)
	{
		skinnedMesh = new gef::SkinnedMeshInstance(*skeleton);
		skinnedMesh->set_mesh(mesh);
		blend_tree = new blendTree(skinnedMesh->bind_pose());
	}

	//set transform
	gef::Matrix44 mesh_transform;
	mesh_transform.SetIdentity();
	mesh_transform.Scale(gef::Vector4(0.01, 0.01, 0.01));
	skinnedMesh->set_transform(mesh_transform);

	//return mesh
	return skinnedMesh;
}

void anim3D::loadTargetAnimation(gef::Platform& platform, const char* anim_fileName, const char* animName, std::string animationIndex)
{
	//loads in animation from file
	currentAnimation = LoadAnimation(anim_fileName, animName, platform);

	//checking if animation is read in
	if (currentAnimation != NULL)
	{
		//adding animation to containers
		animations.insert(str_animations(animationIndex, *currentAnimation));
		animNames.push_back(animationIndex);
	}
}

void anim3D::cleanup()
{
	currentAnimation = NULL;
	delete currentAnimation;
}

gef::Skeleton * anim3D::GetSkeleton(gef::Scene* scene)
{
	//creating new variable  and getting skeleton
	gef::Skeleton* skeleton = NULL;
	if (scene)
	{
		if (scene->skeletons.size() > 0)
			skeleton = scene->skeletons.front();
	}

	//return the skeleton
	return skeleton;
}

gef::Mesh* anim3D::GetMesh(gef::Scene* scene, gef::Platform& platform)
{
	//creating new mesh
	gef::Mesh* mesh = NULL;

	//checking scene and getting mesh
	if (scene)
	{
		// now check to see if there is any mesh data in the file, if so lets create a mesh from it
		if (scene->mesh_data.size() > 0)
			mesh = scene->CreateMesh(platform, scene->mesh_data.front());
	}

	//returning the mesh
	return mesh;
}

gef::Animation* anim3D::LoadAnimation(const char* anim_scene_filename, const char* anim_name, gef::Platform &platform)
{
	gef::Animation* anim = NULL;

	gef::Scene anim_scene;
	if (anim_scene.ReadSceneFromFile(platform, anim_scene_filename))
	{
		// if the animation name is specified then try and find the named anim
		// otherwise return the first animation if there is one
		std::map<gef::StringId, gef::Animation*>::const_iterator anim_node_iter;
		if (anim_name)
			anim_node_iter = anim_scene.animations.find(gef::GetStringId(anim_name));
		else
			anim_node_iter = anim_scene.animations.begin();

		if (anim_node_iter != anim_scene.animations.end())
			anim = new gef::Animation(*anim_node_iter->second);
	}

	return anim;
}

void anim3D::InitBlendTree(gef::SkinnedMeshInstance* skinnedMesh)
{
	//checking if variables are not null
	if (skinnedMesh && skinnedMesh->bind_pose().skeleton())
	{
		//calling function to initalise the blend tree
		blend_tree->init(skinnedMesh->bind_pose());

		//pushing back the vector from function
		linearblend_nodes.push_back(SetupBlend_Clips(skinnedMesh, animNames.at(0), animNames.at(1), true));
		linearblend_nodes.push_back(SetupBlend_Clips(skinnedMesh, animNames.at(2), animNames.at(3), false));
		linearblend_nodes.push_back(SetupBlend_Nodes(skinnedMesh, linearblend_nodes.at(0), linearblend_nodes.at(1)));

		//setting input of the blend tree
		blend_tree->output.setInput(0, linearblend_nodes.at(linearblend_nodes.size() -1));
	}

	//start function in the blend tree
	blend_tree->start();
}

void anim3D::changeBlendTreeInput(int nodeNum, bool blend)
{
	//if blend is true
	if (blend)
	{
		//set input of the last node = blended input
		blend_tree->output.setInput(0, linearblend_nodes.at(linearblend_nodes.size() - 1));
	}
	else
	{
		//set input to the number of the blend node vector if in range
		if (nodeNum < linearblend_nodes.size() && nodeNum >= 0)
		{
			blend_tree->output.setInput(0, linearblend_nodes.at(nodeNum)->inputs[0].node);
		}
	}
}

linearBlendNode* anim3D::SetupBlend_Clips(gef::SkinnedMeshInstance* skinnedMesh, std::string animName, std::string animName2, bool speedAdjustment)
{
	//creating new variables
	float tempDuration;
	clipNode* clip_node_first = new clipNode(skinnedMesh->bind_pose());
	clipNode* clip_node_second = new clipNode(skinnedMesh->bind_pose());

	//if durations are different set variable
	if (animations.at(animName).duration() != animations.at(animName2).duration())
	{
		tempDuration = animations.at(animName).duration() / animations.at(animName2).duration();
	}
	
	//set animation to each variable
	clip_node_first->setClip(&animations.at(animName), skinnedMesh->bind_pose());
	clip_node_second->setClip(&animations.at(animName2), skinnedMesh->bind_pose());

	//if speed is going to be adjusted 
	if (speedAdjustment)
	{
		//setting variables
		clip_node_first->speedMin = 1.f;
		clip_node_first->speedMax = animations.at(animName).duration() / animations.at(animName2).duration();

		clip_node_second->speedMin = animations.at(animName2).duration() / animations.at(animName).duration();
		clip_node_second->speedMax = 1.f;

		clip_node_first->speedAdjustment = true;
		clip_node_second->speedAdjustment = true;
	}

	//creating a new variable from clips
	linearBlendNode* linearBlend_node = new linearBlendNode(skinnedMesh->bind_pose());
	linearBlend_node->setInput(0, clip_node_first);
	linearBlend_node->setInput(1, clip_node_second);

	//return the new variable
return linearBlend_node;
}

linearBlendNode* anim3D::SetupBlend_Nodes(gef::SkinnedMeshInstance* skinnedMesh, linearBlendNode* node, linearBlendNode* node2)
{
	//creating new variable from nodes
	linearBlendNode* linearBlend_node = new linearBlendNode(skinnedMesh->bind_pose());
	linearBlend_node->setInput(0, node);
	linearBlend_node->setInput(1, node2);

	//return the new variable
	return linearBlend_node;
}