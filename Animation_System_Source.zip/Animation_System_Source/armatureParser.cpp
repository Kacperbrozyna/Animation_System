#include "armatureParser.h"

armatureParser::armatureParser()
{}

armatureParser::~armatureParser()
{}

void armatureParser::Init(rapidjson::Document& tex_document, rapidjson::Document& ske_document, gef::Texture* sprite_texture, gef::Vector2 screen_pos, gef::Vector2 scale)
{
	//setting the texture
	set_texture(sprite_texture);

	//setting singular variables from JSON 
	spriteAnim = new SpriteAnimation();
	spriteAnim->frame_rate = ske_document["frameRate"].GetFloat();
	spriteAnim->name = ske_document["name"].GetString();
	spriteAnim->frame_index = 0;
	spriteAnim->current_animation = NULL;

	screenPos = screen_pos;

	//looping through reading armature values from JSON
	const rapidjson::Value& armature_array = ske_document["armature"];
	for (int armature_num = 0; armature_num < (int)armature_array.Size(); ++armature_num)
	{
		spriteAnim->armature = ReadArmatureFromJSON(armature_array[armature_num]);
	}
	
	//looping through reading animation values from JSON
	const rapidjson::Value& animation_array = ske_document["armature"][0]["animation"];
	for  (int animation_num = 0;  animation_num < (int)animation_array.Size(); ++animation_num)
	{
		spriteAnim->animations.push_back(ReadAnimationFromJSON(animation_array[animation_num]));
	}

	//looping through reading slot values from JSON
	const rapidjson::Value& slot_array = ske_document["armature"][0]["slot"];
	for (int slot_num = 0; slot_num < (int)slot_array.Size(); ++slot_num)
	{
		spriteAnim->slots.push_back(ReadSlotFromJSON(slot_array[slot_num]));
	}

	//looping through reading bone values from JSON
	const rapidjson::Value& bones_array = ske_document["armature"][0]["bone"];
	for (int bones_num = 0; bones_num < (int)bones_array.Size(); ++bones_num)
	{
		spriteAnim->bones.push_back(ReadBoneFromJSON(bones_array[bones_num]));
	}

	//looping through reading skin slot values from JSON
	const rapidjson::Value& skinslot_array = ske_document["armature"][0]["skin"][0]["slot"];
	for (int skinslot_num = 0; skinslot_num < (int)skinslot_array.Size(); ++skinslot_num)
	{
		spriteAnim->Skinslots.push_back(ReadSkinSlotFromJSON(skinslot_array[skinslot_num]));
		
	}

	//reading texture atlas from JSON and setting transform
	spriteAnim->text_atlas = ReadTextureAtlasFromJSON(tex_document);
	spriteAnim->text_atlas->setTransform(gef::Vector2(screenPos.x, screenPos.y), scale);

	//resizing vector
	sprites.resize(spriteAnim->slots.size());

	//for the size set variables
	for (int i = 0; i < sprites.size(); i++)
	{
		sprites[i].set_texture(sprite_texture);
		sprites[i].set_position(0, 0, 0);
	}

	//setting variables
	sprite_speed = 1.0f;
	sprite_speed /= spriteAnim->armature->frame_rate;
	elapsed_time = 0.0f;
}

void armatureParser::Update(float dt, int animationNum)
{
	//updating varibles
	elapsed_time += dt;
	spriteAnim->current_animation = spriteAnim->animations.at(animationNum);

	//checks and sets variables
	if (elapsed_time >= sprite_speed)
	{
		spriteAnim->frame_index += 1;
		if (spriteAnim->current_animation != NULL)
		{
			if (spriteAnim->frame_index >= spriteAnim->current_animation->duration)
			{
				spriteAnim->frame_index = 0;
			}
		}

		elapsed_time = 0.f;
	}

	//function to calculate bones and transforms
	CalculateWorldBoneTransform(spriteAnim->current_animation, spriteAnim->frame_index);
	CalculateFinalTransform();
}

void armatureParser::Render(gef::SpriteRenderer* sprite_renderer)
{
	//looping through to check names and calls function to set and render
	for (int it = 0; it != spriteAnim->slots.size(); it++)
	{
		for (int ite = 0; ite != spriteAnim->Skinslots.size(); ite++)
		{
			if (spriteAnim->slots.at(it)->name == spriteAnim->Skinslots.at(ite)->name)
			{
				SetSpriteSizeandPositionFrame(&sprites[it], screenPos.x, screenPos.y, spriteAnim->text_atlas, spriteAnim->Skinslots.at(ite)->Partname);
				sprite_renderer->DrawSprite(sprites[it], spriteAnim->slots.at(it)->final_transform);
			}
		}
	}

}

void armatureParser::CalculateWorldBoneTransform(Animation* anim, int current_frame)
{
	//checks if animation is valid
	if (anim != NULL)
	{

		//for each bone key
		for (auto& bK : anim->bone_keys)
		{

			float start_time = 0;

			//for each translation key set variable
			for (auto& tK : bK->translation_keys)
			{
				tK->start_time = start_time;
				start_time += tK->time_to_next_key;
			}

			start_time = 0;

			//for each rotation key set variable
			for (auto& rK : bK->rotation_keys)
			{
				rK->start_time = start_time;
				start_time += rK->time_to_next_key;
			}
		}
	}

	//for each bone 
	for (auto& bone : spriteAnim->bones)
	{
		//setting variables
		gef::Matrix33 translation, rotation;
		translation.SetIdentity();
		rotation.SetIdentity();

		float localX = bone->local_bone_pos.x;
		float localY = bone->local_bone_pos.y;
		float localRot = bone->local_rot;

		//checks if animation is valid
		if (anim != NULL)
		{
			//for each bone key
			for (auto& bKey : anim->bone_keys)
			{
				//checks the name
				if (bone->name == bKey->name)
				{
					//loops for the size of rotation keys
					for (int currKey = 0; currKey < bKey->rotation_keys.size(); currKey++)
					{
					
						//setting variables
						int nextKey = currKey >= bKey->rotation_keys.size() - 1 ? 0 : currKey + 1;
						if (current_frame >= bKey->rotation_keys[currKey]->start_time && current_frame < bKey->rotation_keys[nextKey]->start_time)
						{
							float time = (current_frame - bKey->rotation_keys[currKey]->start_time) / (bKey->rotation_keys[nextKey]->start_time - bKey->rotation_keys[currKey]->start_time);
							localRot += (lerp(bKey->rotation_keys[currKey]->rotation, bKey->rotation_keys[nextKey]->rotation, time));
						}

						else if(currKey == nextKey)
						{
							localRot += bKey->rotation_keys[currKey]->rotation;
						}
					}

					//loops for the size of translation keys
					for (int currKey = 0; currKey < bKey->translation_keys.size(); currKey++)
					{
						//setting variables
						int nextKey = currKey >= bKey->translation_keys.size() - 1 ? 0 : currKey + 1;
						if (current_frame >= bKey->translation_keys[currKey]->start_time && current_frame < bKey->translation_keys[nextKey]->start_time)
						{
							float time = (current_frame - bKey->translation_keys[currKey]->start_time) / (bKey->translation_keys[nextKey]->start_time - bKey->translation_keys[currKey]->start_time);
							gef::Vector2 lerp_anim_pos = lerp(bKey->translation_keys[currKey]->translation, bKey->translation_keys[nextKey]->translation, time);
							localX += lerp_anim_pos.x;
							localY += lerp_anim_pos.y;
						}

						else if(currKey == nextKey)
						{
							localX += bKey->translation_keys[currKey]->translation.x;
							localY += bKey->translation_keys[currKey]->translation.y;
						}
					}
					break;
				}
			}

		}

		//setting transform variables
		rotation.Rotate(gef::DegToRad(localRot));
		translation.SetTranslation(gef::Vector2(localX, localY));
		bone->modified_local_transform = rotation * translation;

		if (bone->name == "root")
		{
			bone->world_transform = bone->modified_local_transform;
		}
	}

	
	//for each bone
	for (auto& bone : spriteAnim->bones)
	{ 
		// ""
		for(auto& child_bone : spriteAnim->bones)
		{
			//if check is correct set transform
			if (bone->name == child_bone->parent)
			{
				child_bone->world_transform = child_bone->modified_local_transform * bone->world_transform;
			}
		}
	}
}

void armatureParser::CalculateFinalTransform()
{
	gef::Matrix33 offset, bone, subtexture, rig;
	
	//check for validity
	if (spriteAnim->slots.size() > 1)
	{
		//for each slot
		for (auto& Slot : spriteAnim->slots)
		{

			offset.SetIdentity();
			bone.SetIdentity();
			subtexture.SetIdentity();
			rig.SetIdentity();


			//setting transform if checks are true
			rig = spriteAnim->text_atlas->transform;

			for (auto& skin_slot : spriteAnim->Skinslots)
			{
				if ("parts/" + Slot->name == "parts/" + skin_slot->name)
				{
					offset = skin_slot->offset_transform;

					for (auto& text : spriteAnim->text_atlas->subTextures)
					{
						if (skin_slot->Partname == text.subName)
						{
							subtexture = text.transform;
						}
					}
				}
			}


			for (auto& b : spriteAnim->bones)
			{
				if (Slot->name == b->name)
				{
					bone = b->world_transform;
				}
			}

			Slot->final_transform = subtexture * offset * bone * rig;
		}

		
	}

}

textureAtlas* armatureParser::ReadTextureAtlasFromJSON(rapidjson::Document& tex_document)
{
	//creates a new texture atlas and sets value
	textureAtlas* texture_atlas = new textureAtlas();
	texture_atlas->name = tex_document["name"].GetString();
	texture_atlas->width = tex_document["width"].GetFloat();
	texture_atlas->height = tex_document["height"].GetFloat();

	const rapidjson::Value& subtexture_array = tex_document["SubTexture"];
	for (int subtex_num = 0; subtex_num < (int)subtexture_array.Size(); ++subtex_num)
	{
		//reads a new subtexture from JSON and adds it to vector
		subTexture* subtexture = ReadSubTextureFromJSON(subtexture_array[subtex_num]);

		texture_atlas->subTextures.push_back(*subtexture);

		delete subtexture;
	}

	//return the new texture atlas
	return texture_atlas;
}

subTexture* armatureParser::ReadSubTextureFromJSON(const rapidjson::Value& array_pos)
{
	//create a new subtexture and sets variables
	subTexture* sub_texture = new subTexture();
	sub_texture->subName = array_pos["name"].GetString();
	sub_texture->subWidth = array_pos["width"].GetFloat();
	sub_texture->subHeight = array_pos["height"].GetFloat();
	sub_texture->subX = array_pos["x"].GetFloat();
	sub_texture->subY = array_pos["y"].GetFloat();

	if (array_pos.HasMember("frameX"))
	{
		sub_texture->subFrameX = array_pos["frameX"].GetFloat();
	}
	else
	{
		sub_texture->subFrameX = 0;
	}

	if (array_pos.HasMember("frameY"))
	{
		sub_texture->subFrameY = array_pos["frameY"].GetFloat();
	}
	else
	{
		sub_texture->subFrameY = 0;
	}

	if (array_pos.HasMember("frameWidth"))
	{
		sub_texture->subFrameWidth = array_pos["frameWidth"].GetFloat();
	}
	else
	{
		sub_texture->subFrameWidth = array_pos["width"].GetFloat();
	}

	if (array_pos.HasMember("frameHeight"))
	{
		sub_texture->subFrameHeight = array_pos["frameHeight"].GetFloat();
	}
	else
	{
		sub_texture->subFrameHeight = array_pos["height"].GetFloat();
	}

	//builds the transform and returns the subtexture
	sub_texture->BuildTransform();

	return sub_texture;
}

Armature* armatureParser::ReadArmatureFromJSON(const rapidjson::Value& array_pos)
{
	//creates a new armature and sets variables
	Armature* arm = new Armature();

	arm->frame_rate = array_pos["frameRate"].GetFloat();
	arm->name = array_pos["name"].GetString();

	//returns arm
	return arm;
}



Slot* armatureParser::ReadSlotFromJSON(const rapidjson::Value& array_pos)
{
	//creates a new slot and set variables
	Slot* slot = new Slot();

	slot->name = array_pos["name"].GetString();
	if (array_pos.HasMember("parent"))
	{
		slot->parentName = array_pos["parent"].GetString();
	}
	else
	{
		slot->parentName = "none";
	}

	//return slot
	return slot;
}

SkinSlot* armatureParser::ReadSkinSlotFromJSON(const rapidjson::Value& array_pos)
{
	//creates a new skin slot and sets variables
	SkinSlot* skin_slot = new SkinSlot();
	skin_slot->name = array_pos["name"].GetString();
	skin_slot->Partname = array_pos["display"][0]["name"].GetString();
	skin_slot->x = array_pos["display"][0]["transform"]["x"].GetFloat();
	skin_slot->y = array_pos["display"][0]["transform"]["y"].GetFloat();
	
	if (skin_slot->rot = array_pos["display"][0]["transform"].HasMember("skY"))
	{
		skin_slot->rot = array_pos["display"][0]["transform"]["skY"].GetFloat();
	}
	else
	{
		skin_slot->rot = 0;
	}
	
	//builds a transform
	skin_slot->rotation.SetIdentity();
	skin_slot->translation.SetIdentity();
	skin_slot->offset_transform.SetIdentity();

	skin_slot->rotation.Rotate(gef::DegToRad((skin_slot->rot)));
	skin_slot->translation.SetTranslation(gef::Vector2(skin_slot->x, skin_slot->y));

	skin_slot->offset_transform = skin_slot->rotation * skin_slot->translation;

	//returns the skin slot
	return skin_slot;
}

Bone* armatureParser::ReadBoneFromJSON(const rapidjson::Value& array_pos)
{
	//creates a new bone and sets variable
	Bone* bone = new Bone();

	bone->name = array_pos["name"].GetString();

	if (array_pos.HasMember("parent"))
	{
		bone->parent = array_pos["parent"].GetString();
	}
	else
	{
		bone->parent = "none";
	}

	if (array_pos.HasMember("transform"))
	{
		bone->local_bone_pos.x = array_pos["transform"]["x"].GetFloat();
		bone->local_bone_pos.y = array_pos["transform"]["y"].GetFloat();
		bone->local_rot = array_pos["transform"]["skY"].GetFloat();
	}
	else
	{
		bone->local_bone_pos.x = 0.f;
		bone->local_bone_pos.y = 0.f;
		bone->local_rot = 0.f;
	}



	//returns the new bone
	return bone;
}

Animation* armatureParser::ReadAnimationFromJSON(const rapidjson::Value& array_pos)
{
	//create a new animation and sets variable
	Animation* anim = new Animation();

	anim->duration = array_pos["duration"].GetFloat();
	anim->name = array_pos["name"].GetString();

	bool hasBones = array_pos.HasMember("bone");

	if (hasBones)
	{
		const rapidjson::Value& bone_array = array_pos["bone"];
		for (int bone_num = 0; bone_num < bone_array.Size(); ++bone_num)
		{
			//creates a new bone key and sets varibles 
			BoneKey* bone_key = new BoneKey();
			bone_key->name = bone_array[bone_num]["name"].GetString();

			if (bone_array[bone_num].HasMember("translateFrame"))
			{
				for (int i = 0; i < bone_array[bone_num]["translateFrame"].Size(); i++)
				{
					bone_key->translation_keys.push_back(ReadTranslationKeyDataFromJSON(bone_array[bone_num]["translateFrame"][i]));
				}
			}

			if (bone_array[bone_num].HasMember("rotateFrame"))
			{
				for (int i = 0; i < bone_array[bone_num]["rotateFrame"].Size(); i++)
				{
					bone_key->rotation_keys.push_back(ReadRotationKeyDataFromJSON(bone_array[bone_num]["rotateFrame"][i]));
				}
			}

			//adding new bone key to new anim
			anim->bone_keys.push_back(bone_key);
		}
	}

	//return the new animation
	return anim;
}

TranslationKey* armatureParser::ReadTranslationKeyDataFromJSON(const rapidjson::Value& array_pos)
{
	//creates a new translation key and sets variables
	TranslationKey* trans_key = new TranslationKey();

	float time_to_next_key = array_pos["duration"].GetFloat();

	bool hasTranslationX = array_pos.HasMember("x");
	bool hasTranslationY = array_pos.HasMember("y");

	float translationX = hasTranslationX ? array_pos["x"].GetFloat() : 0;
	float translationY = hasTranslationY ? array_pos["y"].GetFloat() : 0;

	trans_key->time_to_next_key = time_to_next_key;
	trans_key->translation = gef::Vector2(translationX, translationY);
	
	//returns the new translation key
	return trans_key;
}

RotationKey* armatureParser::ReadRotationKeyDataFromJSON(const rapidjson::Value& array_pos)
{
	//create a new rotation key and sets variables
	RotationKey* rot_key = new RotationKey();

	float time_to_next_key = array_pos["duration"].GetFloat();

	bool hasRotation = array_pos.HasMember("rotate");

	float rotation = hasRotation ? array_pos["rotate"].GetFloat() : 0;

	rot_key->time_to_next_key = time_to_next_key;
	rot_key->rotation = rotation;

	//return the new rotation key 
	return rot_key;
}

gef::Vector2 armatureParser::lerp(gef::Vector2 start_pos, gef::Vector2 end_pos, float time)
{
	//sets variables by calculation
	float x = (1.f - time) * start_pos.x + time * end_pos.x;
	float y = (1.f - time) * start_pos.y + time * end_pos.y;

	//returns the variables
	return gef::Vector2(x, y);
}

float armatureParser::lerp(float startAngle, float endAngle, float time)
{
	//calculates new variables
	float angleDiff = endAngle - startAngle;
	float angle; 

	if (angleDiff > 180)
	{
		angleDiff -= 360;
	}
	else if (angleDiff < -180)
	{
		angleDiff += 360;
	}

	angle = startAngle + time * angleDiff;

	//return the new variable
	return angle;
}

void armatureParser::SetSpriteSizeandPositionFrame(gef::Sprite* sprite, float screen_x, float screen_y, textureAtlas * texture_atlas, std::string name)
{
	//loops for the size of slots
	for (int it = 0; it != spriteAnim->slots.size(); it++)
	{
		//checks the name
		if  (name == texture_atlas->subTextures.at(it).subName)
		{
			//setting new variables
			float width = texture_atlas->subTextures.at(it).subWidth;
			float height = texture_atlas->subTextures.at(it).subHeight;
			float x = texture_atlas->subTextures.at(it).subX;
			float y = texture_atlas->subTextures.at(it).subY;
			float frame_width = texture_atlas->subTextures.at(it).subFrameWidth;
			float frame_height = texture_atlas->subTextures.at(it).subFrameHeight;
			float frameX = texture_atlas->subTextures.at(it).subFrameX;
			float frameY = texture_atlas->subTextures.at(it).subFrameY;

			//setting sprite variables
			sprite->set_width(width);
			sprite->set_height(height);

			sprite->set_uv_width(width / texture_atlas->width);
			sprite->set_uv_height(height / texture_atlas->height);

			float u = x / texture_atlas->width;
			float v = y / texture_atlas->height;

			sprite->set_uv_position(gef::Vector2(u, v));

			sprite->set_position(gef::Vector4(screen_x, screen_y, 0.f));
		}
	}
}