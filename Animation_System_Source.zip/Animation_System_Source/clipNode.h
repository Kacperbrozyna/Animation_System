#pragma once
#include "blendNode.h"
#include "motion_clip_player.h"

//inherited class
class clipNode : public blendNode
{
public:
	clipNode(gef::SkeletonPose bindpose);
	~clipNode();

	//function to set clip
	void setClip(const gef::Animation* anim, gef::SkeletonPose  pose);

	//override function to start
	void startInteral() override;
	
	//override update function
	bool updateInternal(float frame_time) override;

	//creating variables
	float speedMin, speedMax, speedMod;
	bool speedAdjustment;
	MotionClipPlayer clipPlayer;
	std::string animationName;
};

