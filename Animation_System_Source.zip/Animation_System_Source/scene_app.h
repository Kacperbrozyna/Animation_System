#ifndef _SCENE_APP_H
#define _SCENE_APP_H

#include <system/application.h>
#include <maths/vector2.h>
#include <graphics/sprite.h>
#include <graphics/renderer_3d.h>
#include <input/input_manager.h>
#include <input/touch_input_manager.h>
#include "animationSystem.h"
#include "load_json.h"
#include "picking.h"


// FRAMEWORK FORWARD DECLARATIONS
namespace gef
{
	class Platform;
	class SpriteRenderer;
	class Font;
	class InputManager;
}


class SceneApp : public gef::Application
{
public:
	SceneApp(gef::Platform& platform);

	//basic functions
	void Init();
	void CleanUp();
	bool Update(float frame_time);
	void Render();
private:

	//hud related functions
	void InitFont();
	void CleanUpFont();
	void DrawHUD();

	//functions to setup 3D
	void SetupLights();
	void SetupCamera();

	//variables for 3D space
	gef::Renderer3D* renderer_3d_;
	gef::Vector4 camera_eye_;
	gef::Vector4 camera_lookat_;
	gef::Vector4 camera_up_;
	float camera_fov_;
	float near_plane_;
	float far_plane_;

	//creating variables
	gef::SpriteRenderer* sprite_renderer_;
	gef::Font* font_;
	gef::InputManager* input_manager_;
	float fps_;

	//creating spirte variables
	gef::Texture* sprite_texture_;
	gef::Texture* sprite_texture_2;
	gef::Sprite sprite_;
	gef::Sprite sprite_2;
	gef::Vector2 spritePos;

	//my animation sysem obj
	animationSystem animation_system;

	//creating mesh for 3D model
	gef::SkinnedMeshInstance* player_;

	//variable to keep track of specific 2D animations
	int animationType, boneAnimation, frameAnimation;

	//variable for 2D scale
	float rig_scale;

	//variable to check for ragdoll and kinematic
	bool is_ragdoll_simulating_;
	bool is_kinematic_simulating_;
	bool is_kinematic_set;

	//variable for kinematic
	float ndc_zmin_;
	gef::Vector4 effector_position_;
};

#endif // _SCENE_APP_H
