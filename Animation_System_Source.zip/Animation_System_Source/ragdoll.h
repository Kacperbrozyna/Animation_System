#ifndef rag_dollH
#define rag_dollH

#include "btBulletDynamicsCommon.h"
#include "animation/skeleton.h"

class Ragdoll
{
public:
	Ragdoll();
	~Ragdoll();

	//function to initalise, update pose and ragdoll
	void Init(const gef::SkeletonPose& bind_pose, btDiscreteDynamicsWorld* dynamics_world, const char* physics_filename);
	void UpdatePoseFromRagdoll();
	void UpdateRagdollFromPose(gef::SkeletonPose previousPose, float frame_time);

	//getters and setters
	inline gef::SkeletonPose& pose() { return pose_; }
	inline void set_pose(const gef::SkeletonPose& pose) {	pose_ = pose;	}
	inline void set_scale_factor(float scale_factor) { scale_factor_ = scale_factor; }
	inline float scale_factor() const { return scale_factor_;  }
	inline std::vector<gef::Matrix44>& bone_world_matrices() { return bone_world_matrices_; }

private:
	//creating variables
	gef::SkeletonPose bind_pose_;
	gef::SkeletonPose pose_;
	std::vector<gef::Matrix44> bone_rb_offset_matrices_;
	std::vector<btRigidBody*> bone_rbs_;
	std::vector<gef::Matrix44> bone_world_matrices_;
	float scale_factor_;
};

//creating variables
gef::Matrix44 btTransform2Matrix(const btTransform& transform);
btTransform Matrix2btTransform(const gef::Matrix44& mtx);

#endif // !_animation_system.rag_dollH
